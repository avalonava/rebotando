// Shared by the site and the edit page: text formatting and post styles
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

// Spotify and YouTube links become embedded players (IDs are strictly matched, so this is safe)
function embed(raw) {
  let u;
  try { u = new URL(raw.replace(/&amp;/g, "&")); } catch (e) { return ""; }
  const host = u.hostname.replace(/^(www|m|music|open)\./, "");
  const frame = (src, style) => `<iframe src="${src}" loading="lazy" style="${style}" frameborder="0" ` +
    `allow="autoplay; clipboard-write; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;

  if (u.hostname === "open.spotify.com") {
    const m = u.pathname.match(/\/(track|album|playlist|episode|show|artist)\/([A-Za-z0-9]+)/);
    if (!m) return "";
    const h = ["track", "episode"].includes(m[1]) ? 152 : 352;
    return frame(`https://open.spotify.com/embed/${m[1]}/${m[2]}`, `width:100%;height:${h}px;border:0;margin:6px 0;`);
  }

  let id = "", list = u.searchParams.get("list") || "";
  if (host === "youtu.be") id = u.pathname.slice(1, 12);
  else if (host === "youtube.com") {
    if (u.pathname === "/watch") id = u.searchParams.get("v") || "";
    else { const m = u.pathname.match(/^\/(?:shorts|embed|live)\/([\w-]{11})/); if (m) id = m[1]; }
  } else return "";
  const yt = "width:100%;aspect-ratio:16/9;border:0;margin:6px 0;";
  if (/^[\w-]{11}$/.test(id)) return frame(`https://www.youtube-nocookie.com/embed/${id}`, yt);
  if (/^[\w-]+$/.test(list)) return frame(`https://www.youtube-nocookie.com/embed/videoseries?list=${list}`, yt);
  return "";
}

// **bold**, *italic*, [text](https://link) and bare URLs (embeds players unless noEmbed)
function fmt(s, noEmbed) {
  return esc(s)
    .replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")
    .replace(/\*(.+?)\*/g, "<i>$1</i>")
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)|https?:\/\/[^\s<]+/g,
      (m, t, u) => t ? `<a href="${u}">${t}</a>` : ((!noEmbed && embed(m)) || `<a href="${m}">${m}</a>`));
}

function styled(style, text) {
  if (!style || style === "auto") style = /^["“«]/.test(text) ? "cita" : "normal";
  const t = fmt(text);
  return ({
    cita: `<blockquote>${t}</blockquote>`,
    grande: `<div class="big">${t}</div>`,
    centrado: `<div class="center">${t}</div>`,
    pequeno: `<div class="sm">${t}</div>`,
    mono: `<div class="mono">${t}</div>`,
  })[style] || `<div>${t}</div>`;
}
