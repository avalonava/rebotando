// Shared by the main page and each post's own page

function render(p) {
  let h = '<div class="post">';
  if (p.title) h += `<b>${fmt(p.title, true)}</b><br>`;
  for (const f of p.files || []) {
    const u = `/media/${f.key}`;
    if (f.type.startsWith("image/")) h += `<img class="ph" loading="lazy" decoding="async" src="${u}" alt="${esc(f.name||"")}" onload="this.classList.remove('ph')"><br>`;
    else if (f.type.startsWith("audio/")) h += `<audio controls preload="none" src="${u}"></audio><br>`;
    else if (f.type === "application/pdf" || /\.pdf$/i.test(f.name || "")) h += `<a href="${u}"><canvas data-pdf="${u}"></canvas></a><a href="${u}">${esc(f.name||"PDF")}</a><br>`;
    else if (f.type.startsWith("video/")) h += `<video class="ph" controls playsinline preload="none" width="100%" data-src="${u}#t=0.1" onloadedmetadata="this.classList.remove('ph')"></video><br>`;
    else h += `<a href="${u}">${esc(f.name||"file")}</a><br>`;
  }
  if (p.text) h += styled(p.style, p.text);
  return h + `</div><hr>`;
}

// Start loading videos only when they get close to the screen
function lazyVideos() {
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    const v = e.target; io.unobserve(v); v.preload = "metadata"; v.src = v.dataset.src;
  }), { rootMargin: "400px" });
  document.querySelectorAll("video[data-src]:not([data-seen])").forEach(v => { v.dataset.seen = 1; io.observe(v); });
}

// First-page preview for PDFs, drawn only when near the screen (pdf.js loads on first use)
let lib;
function pdfPreviews() {
  const cs = [...document.querySelectorAll("canvas[data-pdf]:not([data-seen])")];
  if (!cs.length) return;
  cs.forEach(c => { c.dataset.seen = 1; });
  const base = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/";
  const load = () => lib || (lib = new Promise((ok, no) => {
    const sc = document.createElement("script");
    sc.src = base + "pdf.min.js";
    sc.onload = () => { pdfjsLib.GlobalWorkerOptions.workerSrc = base + "pdf.worker.min.js"; ok(); };
    sc.onerror = () => no(new Error("no cargó pdf.js"));
    document.head.appendChild(sc);
  }));
  const fail = (c, e) => {
    c.hidden = true;
    c.closest("a").insertAdjacentHTML("afterend",
      "<small>Vista previa no disponible (" + esc(String((e && e.message) || e)) + ")</small><br>");
  };
  const draw = async c => {
    try {
      await load();
      const r = await fetch(c.dataset.pdf);
      if (!r.ok) throw new Error("HTTP " + r.status);
      const data = new Uint8Array(await r.arrayBuffer());
      const pg = await (await pdfjsLib.getDocument({ data }).promise).getPage(1);
      const dpr = window.devicePixelRatio || 1;
      const w = document.getElementById("posts").clientWidth;
      const vp = pg.getViewport({ scale: (w / pg.getViewport({ scale: 1 }).width) * dpr });
      c.width = vp.width; c.height = vp.height; c.style.width = (vp.width / dpr) + "px";
      await pg.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise;
    } catch (e) { fail(c, e); }
  };
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { io.unobserve(e.target); draw(e.target); }
  }), { rootMargin: "400px" });
  cs.forEach(c => io.observe(c));
}

