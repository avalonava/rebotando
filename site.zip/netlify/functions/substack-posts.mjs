import { getStore } from "@netlify/blobs";

export default async (req) => {
  const q = new URL(req.url).searchParams;
  const store = getStore("substack");
  const site = process.env.SUBSTACK_URL || "https://conexionanalogica.substack.com";

  const slug = q.get("slug");
  if (slug) {
    const post = await store.get("post-" + slug, { type: "json" });
    return post ? Response.json(post) : new Response("not found", { status: 404 });
  }

  const index = ((await store.get("index", { type: "json" })) || [])
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  // Feed: full posts in small batches, newest first
  if (q.get("feed")) {
    const offset = Math.max(0, parseInt(q.get("offset")) || 0);
    const limit = Math.min(10, Math.max(1, parseInt(q.get("limit")) || 4));
    const slice = index.slice(offset, offset + limit);
    const posts = (await Promise.all(slice.map(e => store.get("post-" + e.slug, { type: "json" })))).filter(Boolean);
    return Response.json({ site, total: index.length, count: slice.length, posts });
  }

  return Response.json({ site, posts: index });
};

export const config = { path: "/api/substack-posts" };
