import { getStore } from "@netlify/blobs";

export default async (req) => {
  const slug = new URL(req.url).searchParams.get("slug");
  const store = getStore("substack");

  if (slug) {
    const post = await store.get("post-" + slug, { type: "json" });
    return post ? Response.json(post) : new Response("not found", { status: 404 });
  }

  const posts = ((await store.get("index", { type: "json" })) || [])
    .sort((a, b) => new Date(b.date) - new Date(a.date));
  return Response.json({ site: process.env.SUBSTACK_URL || "https://conexionanalogica.substack.com", posts });
};

export const config = { path: "/api/substack-posts" };
