import { sync } from "../lib/sync.mjs";

export default async () => {
  await sync(20000, { fresh: true });
};

export const config = { schedule: "@weekly" };
