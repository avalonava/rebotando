import { sync } from "../lib/sync.mjs";

export default async () => {
  await sync(20000);
};

export const config = { schedule: "@weekly" };
