import { getStore } from "@netlify/blobs";

export default async (req) => {
  const store = getStore("posts");
  const id = new URL(req.url).searchParams.get("id");

  if (id) {
    const post = /^\d+$/.test(id) ? await store.get(id, { type: "json" }) : null;
    return post ? Response.json(post) : new Response("not found", { status: 404 });
  }

  const { blobs } = await store.list();
  const keys = blobs.map(b => b.key).sort().reverse();
  const posts = await Promise.all(keys.map(k => store.get(k, { type: "json" })));
  return Response.json(posts.filter(Boolean), { headers: { "cache-control": "no-cache" } });
};

export const config = { path: "/api/posts" };
