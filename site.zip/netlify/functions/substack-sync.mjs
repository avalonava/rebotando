import { sync } from "../lib/sync.mjs";

export default async (req) => {
  const q = new URL(req.url).searchParams;
  if (req.method !== "POST" || q.get("key") !== process.env.SECRET)
    return new Response("no", { status: 403 });
  return Response.json(await sync(20000));
};

export const config = { path: "/api/substack-sync" };
