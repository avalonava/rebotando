import { getStore } from "@netlify/blobs";

const SITE = "Cosas que rebotan en mis bóvedas";
const attr = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const plain = s => String(s || "")
  .replace(/\[([^\]]+)\]\(https?:\/\/[^\s)]+\)/g, "$1")
  .replace(/https?:\/\/\S+/g, "")
  .replace(/\*+/g, "")
  .replace(/\s+/g, " ").trim();

// Serves the post page with a title, description and image in the head so
// WhatsApp, iMessage and others can show a preview card when the link is shared.
export default async (req) => {
  const url = new URL(req.url);
  const id = url.pathname.split("/").filter(Boolean).pop();
  let html = await (await fetch(url.origin + "/p.html")).text();
  let status = 200;

  try {
    const post = /^\d+$/.test(id) ? await getStore("posts").get(id, { type: "json" }) : null;
    if (!post) status = 404;
    else {
      const text = plain(post.text);
      const title = plain(post.title) || text.slice(0, 60) || SITE;
      const desc = text.slice(0, 160);
      const img = (post.files || []).find(f => (f.type || "").startsWith("image/"));
      let imgUrl = "";
      if (img) {
        const thumb = await getStore("media").getMetadata(img.key + "-t").catch(() => null);
        imgUrl = url.origin + "/media/" + img.key + (thumb ? "-t" : "");
      }
      const meta = [
        `<meta property="og:type" content="article">`,
        `<meta property="og:site_name" content="${attr(SITE)}">`,
        `<meta property="og:title" content="${attr(title)}">`,
        `<meta property="og:url" content="${attr(url.origin + "/p/" + id)}">`,
        desc && `<meta property="og:description" content="${attr(desc)}">`,
        desc && `<meta name="description" content="${attr(desc)}">`,
        imgUrl && `<meta property="og:image" content="${attr(imgUrl)}">`,
        `<meta name="twitter:card" content="${img ? "summary_large_image" : "summary"}">`,
      ].filter(Boolean).join("\n");
      html = html.replace(/<title>[\s\S]*?<\/title>/, `<title>${attr(title)}</title>`).replace("</head>", meta + "\n</head>");
    }
  } catch (e) { /* fall back to the plain page */ }

  return new Response(html, { status, headers: { "content-type": "text/html; charset=utf-8" } });
};

export const config = { path: "/p/*" };
